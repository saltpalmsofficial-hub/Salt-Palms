# Salt Palms website

This is a free-to-host static starter storefront for Salt Palms.

## Included
- Coastal/surfy responsive storefront
- Uploaded Salt Palms logo
- Product catalogue
- Product image upload in the admin editor (actual image files, converted to browser storage)
- Shopping cart
- Checkout/order capture stored in the current browser
- Customer reviews + admin review deletion
- Admin dashboard with products, site/banner editing, orders, reviews and password change
- No paid hosting required

## Important limitation
This is intentionally a **static/free starter**. The admin data, products, reviews and orders are stored in the browser's localStorage. That means changes made on one device/browser are not automatically shared with customers or another admin device.

The checkout currently records an order but does **not** process real card payments. For a real online store, connect a payment provider and a shared database/auth backend. Do not put payment secrets or a real admin password in frontend JavaScript.

## Launch for free
You can publish these files on a free static host such as GitHub Pages. The site itself does not require a monthly hosting fee.

## Initial admin password
The initial password you supplied is configured as a SHA-256 hash in `app.js`. After first login, change it from the Password tab.
