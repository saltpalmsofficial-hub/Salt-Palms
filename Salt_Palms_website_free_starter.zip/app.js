const DEFAULT_PRODUCTS=[
{id:"p1",name:"Coastal Oversized Tee",price:399,category:"Tops",badge:"Best seller",description:"Relaxed, soft and made for sunny days.",image:""},
{id:"p2",name:"Sunset Club Cap",price:249,category:"Accessories",badge:"New",description:"A classic cap with laid-back surf energy.",image:""},
{id:"p3",name:"Tide & Sand Tote",price:299,category:"Accessories",badge:"",description:"Room for towels, sunscreen and all the little things.",image:""},
{id:"p4",name:"Palm Wave Hoodie",price:599,category:"Tops",badge:"",description:"Cosy coastal layers for breezy evenings.",image:""}
];
const DEFAULT_REVIEWS=[
{name:"Mia",rating:5,text:"Such a cute coastal vibe! The quality is lovely and the packaging felt so special."},
{name:"Kayla",rating:5,text:"My new favourite beach-day brand. Everything feels so easy and summery."},
{name:"Jordan",rating:4,text:"Love the surf-inspired style. Can't wait to order another piece!"}
];
const DEFAULT_SITE={announcement:"🌊 Free shipping on orders over R750 • Salt Palms — made for salty days",heroEyebrow:"SALTY • SUNNY • SURFY",heroTitle:"Made for days<br><em>by the ocean.</em>",heroText:"Easygoing coastal pieces and accessories for beach days, road trips and everything in between.",aboutTitle:"Salt in our hair.<br>Sun on our skin.<br>Nowhere else to be.",aboutText:"Salt Palms is a coastal-inspired clothing and accessories brand built around that feeling you get when the ocean is calling. Think relaxed fits, surfy details, warm sunsets and pieces you'll reach for all summer long."};

const HASH_SEED="621b1f7cebcb1a1caf06e04fb83536a1d59de311c2ecee3f425bc41cf1795aa8";
const state={
products:load("sp_products",DEFAULT_PRODUCTS),
reviews:load("sp_reviews",DEFAULT_REVIEWS),
orders:load("sp_orders",[]),
site:load("sp_site",DEFAULT_SITE),
cart:load("sp_cart",[]),
passwordHash:localStorage.getItem("sp_admin_hash")||HASH_SEED
};
let filter="All", editingImage="";

function load(k,f){try{const v=localStorage.getItem(k);return v?JSON.parse(v):structuredClone(f)}catch{return structuredClone(f)}}
function save(){localStorage.setItem("sp_products",JSON.stringify(state.products));localStorage.setItem("sp_reviews",JSON.stringify(state.reviews));localStorage.setItem("sp_orders",JSON.stringify(state.orders));localStorage.setItem("sp_site",JSON.stringify(state.site));localStorage.setItem("sp_cart",JSON.stringify(state.cart))}
async function hash(s){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400)}
function money(n){return "R"+Number(n).toFixed(2)}
function open(id){document.getElementById(id).classList.add("open")}
function close(id){document.getElementById(id).classList.remove("open")}

function renderProducts(){
 const el=document.getElementById("products"), cats=["All",...new Set(state.products.map(p=>p.category))];
 document.getElementById("categoryFilters").innerHTML=cats.map(c=>`<button class="filter ${filter===c?"active":""}" onclick="filterProducts('${esc(c)}')">${esc(c)}</button>`).join("");
 const ps=filter==="All"?state.products:state.products.filter(p=>p.category===filter);
 el.innerHTML=ps.length?ps.map(p=>`<article class="product-card">
 <div class="product-image">${p.image?`<img src="${p.image}" alt="${esc(p.name)}">`:`<div class="placeholder">🌊</div>`}${p.badge?`<span class="badge">${esc(p.badge)}</span>`:""}</div>
 <div class="product-info"><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" onclick="addToCart('${p.id}')">Add to bag</button></div></div></article>`).join(""):`<p>No products in this collection yet.</p>`;
}
function filterProducts(c){filter=c;renderProducts()}
function renderReviews(){document.getElementById("reviewsList").innerHTML=state.reviews.length?state.reviews.map(r=>`<article class="review"><div class="stars">${"★".repeat(r.rating)}${"☆".repeat(5-r.rating)}</div><p>“${esc(r.text)}”</p><strong>${esc(r.name)}</strong></article>`).join(""):`<p>Be the first to leave a review.</p>`}
function addToCart(id){const found=state.cart.find(x=>x.id===id);if(found)found.qty++;else state.cart.push({id,qty:1});save();renderCart();toast("Added to your bag 🌴")}
function cartCount(){return state.cart.reduce((a,x)=>a+x.qty,0)}
function renderCart(){document.getElementById("cartCount").textContent=cartCount();const el=document.getElementById("cartItems");let total=0;
 el.innerHTML=state.cart.length?state.cart.map(item=>{const p=state.products.find(x=>x.id===item.id);if(!p)return "";total+=p.price*item.qty;return `<div class="cart-line"><img src="${p.image||"assets/salt-palms-logo.jpeg"}" alt=""><div><strong>${esc(p.name)}</strong><div class="qty"><button onclick="changeQty('${p.id}',-1)">−</button>${item.qty}<button onclick="changeQty('${p.id}',1)">+</button></div></div><strong>${money(p.price*item.qty)}</strong></div>`}).join(""):`<p>Your bag is waiting for a little sunshine.</p>`;
 document.getElementById("cartTotal").textContent=money(total);
}
function changeQty(id,d){const x=state.cart.find(i=>i.id===id);if(!x)return;x.qty+=d;if(x.qty<=0)state.cart=state.cart.filter(i=>i.id!==id);save();renderCart()}

function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function applySite(){document.getElementById("announcement").textContent=state.site.announcement;document.querySelector(".hero .eyebrow").textContent=state.site.heroEyebrow;document.querySelector(".hero h1").innerHTML=state.site.heroTitle;document.querySelector(".hero-copy>p:not(.eyebrow)").textContent=state.site.heroText;document.querySelector(".story-card h2").innerHTML=state.site.aboutTitle;document.querySelector(".story-copy").innerHTML=`<p>${esc(state.site.aboutText)}</p>`}
function renderAdminProducts(){document.getElementById("adminProducts").innerHTML=state.products.map(p=>`<div class="admin-product"><img src="${p.image||"assets/salt-palms-logo.jpeg"}" alt=""><div><strong>${esc(p.name)}</strong><div>${money(p.price)} • ${esc(p.category)}</div><small>${esc(p.description)}</small></div><div class="admin-product-actions"><button class="secondary-btn" onclick="editProduct('${p.id}')">Edit</button><button class="danger" onclick="deleteProduct('${p.id}')">Delete</button></div></div>`).join("")||"<p>No products yet.</p>"}
function renderAdminOrders(){const el=document.getElementById("adminOrders");el.innerHTML=state.orders.length?state.orders.slice().reverse().map(o=>`<div class="admin-order"><strong>${esc(o.name)}</strong> — ${esc(o.email)}<br><small>${new Date(o.date).toLocaleString()} • ${esc(o.payment)} • ${money(o.total)}</small><p>${esc(o.address)}, ${esc(o.city)}<br>Phone: ${esc(o.phone)}</p><details><summary>Items</summary>${o.items.map(i=>`<div>${esc(i.name)} × ${i.qty} — ${money(i.price*i.qty)}</div>`).join("")}</details></div>`).join(""):"<p>No orders recorded in this browser.</p>"}
function renderAdminReviews(){document.getElementById("adminReviews").innerHTML=state.reviews.map((r,i)=>`<div class="admin-review"><strong>${esc(r.name)}</strong> <span class="stars">${"★".repeat(r.rating)}</span><p>${esc(r.text)}</p><button class="danger" onclick="deleteReview(${i})">Delete review</button></div>`).join("")||"<p>No reviews.</p>"}

function openAdmin(){open("adminLoginModal")}
async function loginAdmin(e){e.preventDefault();const p=new FormData(e.target).get("password");if(await hash(p)===state.passwordHash){close("adminLoginModal");document.getElementById("adminPanel").classList.add("open");renderAdmin();e.target.reset()}else toast("That password isn't correct.")}
function renderAdmin(){renderAdminProducts();renderAdminOrders();renderAdminReviews();const f=document.getElementById("siteForm");Object.keys(state.site).forEach(k=>{if(f.elements[k])f.elements[k].value=state.site[k]})}
function deleteProduct(id){if(!confirm("Delete this product?"))return;state.products=state.products.filter(p=>p.id!==id);state.cart=state.cart.filter(x=>x.id!==id);save();renderProducts();renderCart();renderAdminProducts();toast("Product deleted")}
function editProduct(id){const p=state.products.find(x=>x.id===id);if(!p)return;editingImage=p.image||"";const f=document.getElementById("productForm");f.reset();f.id.value=p.id;f.name.value=p.name;f.price.value=p.price;f.category.value=p.category;f.badge.value=p.badge;f.description.value=p.description;document.getElementById("productModalTitle").textContent="Edit product";const pr=document.getElementById("productPreview");if(editingImage){pr.src=editingImage;pr.hidden=false}else pr.hidden=true;open("productModal")}
function newProduct(){editingImage="";document.getElementById("productForm").reset();document.getElementById("productForm").id.value="";document.getElementById("productModalTitle").textContent="Add product";document.getElementById("productPreview").hidden=true;open("productModal")}
async function saveProduct(e){e.preventDefault();const f=e.target,id=f.id.value;let image=editingImage;const file=f.image.files[0];if(file)image=await fileToData(file);const obj={id:id||"p"+Date.now(),name:f.name.value,price:Number(f.price.value),category:f.category.value,badge:f.badge.value,description:f.description.value,image};if(id)state.products=state.products.map(p=>p.id===id?obj:p);else state.products.push(obj);save();renderProducts();renderAdminProducts();close("productModal");toast("Product saved")}
function fileToData(file){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file)})}
function submitReview(e){e.preventDefault();const f=new FormData(e.target);state.reviews.push({name:f.get("name"),rating:Number(f.get("rating")),text:f.get("text")});save();renderReviews();renderAdminReviews();close("reviewModal");e.target.reset();toast("Thanks for your review! 🌊")}
function checkout(){if(!state.cart.length){toast("Your bag is empty.");return}close("cartOverlay");open("checkoutModal")}
function placeOrder(e){e.preventDefault();const f=new FormData(e.target);const items=state.cart.map(i=>{const p=state.products.find(x=>x.id===i.id);return{name:p.name,price:p.price,qty:i.qty}});const total=items.reduce((a,i)=>a+i.price*i.qty,0);state.orders.push({date:new Date().toISOString(),name:f.get("name"),email:f.get("email"),phone:f.get("phone"),city:f.get("city"),address:f.get("address"),payment:f.get("payment"),items,total});state.cart=[];save();renderCart();renderAdminOrders();close("checkoutModal");e.target.reset();toast("Order saved! We'll be in touch 🌴")}
function saveSite(e){e.preventDefault();const f=new FormData(e.target);for(const k of Object.keys(state.site))state.site[k]=f.get(k);save();applySite();toast("Site updated")}
async function changePassword(e){e.preventDefault();const f=new FormData(e.target);if(await hash(f.get("current"))!==state.passwordHash){toast("Current password is incorrect.");return}if(f.get("next")!==f.get("confirm")){toast("New passwords don't match.");return}state.passwordHash=await hash(f.get("next"));localStorage.setItem("sp_admin_hash",state.passwordHash);e.target.reset();toast("Admin password changed")}
function deleteReview(i){if(!confirm("Delete this review?"))return;state.reviews.splice(i,1);save();renderReviews();renderAdminReviews()}
function initTabs(){document.querySelectorAll(".admin-tabs button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".admin-tabs button").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".admin-tab,#settingsTab").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.getElementById(b.dataset.tab).classList.add("active")})}

document.getElementById("cartBtn").onclick=()=>{renderCart();open("cartOverlay")};
document.getElementById("adminBtn").onclick=openAdmin;
document.getElementById("reviewBtn").onclick=()=>open("reviewModal");
document.getElementById("checkoutBtn").onclick=checkout;
document.getElementById("adminLoginForm").onsubmit=loginAdmin;
document.getElementById("reviewForm").onsubmit=submitReview;
document.getElementById("checkoutForm").onsubmit=placeOrder;
document.getElementById("siteForm").onsubmit=saveSite;
document.getElementById("passwordForm").onsubmit=changePassword;
document.getElementById("newProduct").onclick=newProduct;
document.getElementById("productForm").onsubmit=saveProduct;
document.getElementById("clearOrders").onclick=()=>{if(confirm("Clear all orders in this browser?")){state.orders=[];save();renderAdminOrders()}};
document.getElementById("logoutAdmin").onclick=()=>document.getElementById("adminPanel").classList.remove("open");
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>close(b.dataset.close));
document.getElementById("productForm").image.onchange=async e=>{if(e.target.files[0]){const p=document.getElementById("productPreview");p.src=await fileToData(e.target.files[0]);p.hidden=false}};
document.getElementById("year").textContent=new Date().getFullYear();
initTabs();applySite();renderProducts();renderReviews();renderCart();
